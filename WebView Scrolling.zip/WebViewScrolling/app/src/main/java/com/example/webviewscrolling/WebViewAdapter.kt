package com.example.webviewscrolling

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.recyclerview.widget.RecyclerView


class WebViewAdapter(private val urls: List<String>) : RecyclerView.Adapter<WebViewAdapter.WebViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): WebViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.webview_item, parent, false)
        return WebViewHolder(view)
    }

    override fun onBindViewHolder(holder: WebViewHolder, position: Int) {
        holder.bind(urls[position])
    }

    override fun getItemCount(): Int = urls.size

    class WebViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val webView: CustomWebview = itemView.findViewById(R.id.webView)

        fun bind(url: String) {
            webView.settings.javaScriptEnabled = true
            webView.loadUrl(url)
        }
    }
}