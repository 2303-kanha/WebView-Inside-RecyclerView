package com.example.webviewscrolling

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.MotionEvent
import android.webkit.WebView
import kotlin.math.abs


class CustomWebview : WebView {
    private var startX = 0f
    private var startY = 0f
    private val scrollThreshold = 10 // Threshold to differentiate scroll direction
    private var onCancelTouchEvent: OnCancelTouchEvent? = null

    constructor(context: Context?) : super(context!!) {
        initWebView()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(
        context!!, attrs
    ) {
        initWebView()
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context!!, attrs, defStyleAttr
    ) {
        initWebView()
    }

    private fun initWebView() {
        isHorizontalScrollBarEnabled = true // Enable horizontal scrollbar
        overScrollMode = OVER_SCROLL_IF_CONTENT_SCROLLS // Allow over-scroll if needed
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                startX = event.x
                startY = event.y
                Log.v("event--", "down")
                // Prevent RecyclerView from intercepting touch events when WebView starts scrolling
                parent.requestDisallowInterceptTouchEvent(true)
                onCancelTouchEvent?.onCancelTouch(true)
            }

            MotionEvent.ACTION_MOVE -> {
                val currentX = event.x
                val currentY = event.y
                val deltaX = currentX - startX
                val deltaY = currentY - startY
                Log.v("event--", "move")

                // Check if the movement is more horizontal or vertical
                if (abs(deltaX.toDouble()) > abs(deltaY.toDouble())) {
                    // Horizontal scrolling
                    if (canScrollHorizontally(if (deltaX > 0) -1 else 1)) {
                        Log.v("horizontal Scrolling", "webview has horizontal scrolling")
                        parent.requestDisallowInterceptTouchEvent(true)
                    } else {
                        Log.v("horizontal Scrolling", "webview reached end of horizontal scrolling")
                        parent.requestDisallowInterceptTouchEvent(true)
                    }
                } else {
                    // Vertical scrolling
                    if (canScrollVertically(if (deltaY > 0) -1 else 1)) {
                        Log.v("vertical Scrolling", "webview has vertical scrolling")
                        parent.requestDisallowInterceptTouchEvent(true)
                    } else {
                        Log.v("vertical Scrolling", "webview reached end of vertical scrolling")
                        parent.requestDisallowInterceptTouchEvent(false)
                    }
                }
                onCancelTouchEvent?.onCancelTouch(true)
            }

            MotionEvent.ACTION_UP -> {
                Log.v("event--", "up")
                parent.requestDisallowInterceptTouchEvent(false)
                onCancelTouchEvent?.onCancelTouch(false)
            }

            MotionEvent.ACTION_CANCEL -> {
                Log.v("event--", "cancel")
                parent.requestDisallowInterceptTouchEvent(false)
                onCancelTouchEvent?.onCancelTouch(false)
            }
        }
        return super.onTouchEvent(event)
    }

    override fun canScrollHorizontally(direction: Int): Boolean {
        // Override to handle horizontal scrolling
        val contentWidth = computeHorizontalScrollRange()
        val viewportWidth = computeHorizontalScrollExtent()
        val scrollX = scrollX
        return if (direction < 0) {
            scrollX > 0 // Scrolling left
        } else {
            scrollX < contentWidth - viewportWidth // Scrolling right
        }
    }

    override fun canScrollVertically(direction: Int): Boolean {
        // Already implemented: Handle vertical scrolling
        val contentHeight = computeVerticalScrollRange()
        val viewportHeight = computeVerticalScrollExtent()
        val scrollY = scrollY
        return if (direction < 0) {
            scrollY > 0 // Scrolling up
        } else {
            scrollY < contentHeight - viewportHeight // Scrolling down
        }
    }

    fun setOnCancelTouchEvent(onCancelTouchEvent: OnCancelTouchEvent?) {
        this.onCancelTouchEvent = onCancelTouchEvent
    }

    interface OnCancelTouchEvent {
        fun onCancelTouch(status: Boolean) {}
    }
}

