package com.example.webviewscrolling

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView


class MainActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: WebViewAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val urls = listOf(
            "https://electionresults.intoday.in/elections/2024/assembly-elections/html/exit-poll/assembly-exit-poll.html?site=it&device=app&v=2.824",
            "https://electionresults.intoday.in/elections/2024/assembly-elections/html/exit-poll/assembly-exit-poll.html?site=it&device=app&v=2.824",
            "https://electionresults.intoday.in/elections/2024/assembly-elections/html/exit-poll/assembly-exit-poll.html?site=it&device=app&v=2.824",
            "https://electionresults.intoday.in/elections/2024/assembly-elections/html/exit-poll/assembly-exit-poll.html?site=it&device=app&v=2.824"
        )

        recyclerView = findViewById(R.id.recyclerView)
        adapter = WebViewAdapter(urls)

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        recyclerView.isNestedScrollingEnabled=true
    }

}